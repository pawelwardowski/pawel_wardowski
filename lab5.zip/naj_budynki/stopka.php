<?php
echo "<footer>&copy; 2025 Moja Strona Testowa</footer>";
?>
