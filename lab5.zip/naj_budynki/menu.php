<?php
echo "<ul>";
echo "<li><a href='index.php'>Strona główna</a></li>";
echo "<li><a href='kontakt.php'>Kontakt</a></li>";
echo "<li><a href='galeria.php'>Galeria</a></li>";
echo "</ul>";
?>
