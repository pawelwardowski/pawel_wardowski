<?php
	$dbhost = 'localhost';
	$dbuser = 'root';
	$dbpass = '';
	$baza = 'moja_strona';
	$login = 'admin';
	$pass = '123';
	
	$link = mysqli_connect($dbhost,$dbuser,$dbpass,$baza);
	//if (!$link) echo '<b>przerwane polaczenie </b>';
	//if(!mysql_select_db($baza)) echo 'nie wybrano bazy';
	
	if (!$link) 
	{
		die('<b>Przerwane połączenie z bazą!</b>');
	}
	mysqli_set_charset($link, "utf8");


	
?>