<?php


function PokazKontakt()
{
    return '
        <h2>Formularz kontaktowy</h2>
        <form method="POST" action="contact.php?task=sendmail">
            
            <label>Twój email:</label><br>
            <input type="email" name="email" required><br><br>

            <label>Temat wiadomości:</label><br>
            <input type="text" name="temat" required><br><br>

            <label>Treść wiadomości:</label><br>
            <textarea name="tresc" rows="6" required></textarea><br><br>

            <input type="submit" value="Wyślij wiadomość">
        </form>
    ';
}

function WyslijMailKontakt($odbiorca)
{
    if (empty($_POST['email']) || empty($_POST['temat']) || empty($_POST['tresc'])) {
        echo "[niewypelnione_pole]<br>";
        echo PokazKontakt();
        return;
    }

    $mail['subject']    = $_POST['temat'];
    $mail['body']       = $_POST['tresc'];
    $mail['sender']     = $_POST['email'];
    $mail['recipient']  = $odbiorca;

    $header  = "From: Formularz kontaktowy <".$mail['sender'].">\n";
    $header .= "MIME-Version: 1.0\nContent-Type: text/plain; charset=utf-8\n";
    $header .= "X-Mailer: PHP/" . phpversion() . "\n";

    mail($mail['recipient'], $mail['subject'], $mail['body'], $header);

    echo "[wiadomosc_wyslana]";
}


function PrzypomnijHaslo($emailDocelowy, $hasloAdmina)
{
    if (empty($_POST['email'])) {
        echo "[niewypelnione_pole]<br>";
        echo FormularzPrzypomnieniaHasla();
        return;
    }

    $nadawca = $_POST['email'];
    $subject = "Przypomnienie hasła do panelu admina";
    $body    = "Hasło administratora to: " . $hasloAdmina;

    $header  = "From: Panel admina <".$nadawca.">\n";
    $header .= "MIME-Version: 1.0\nContent-Type: text/plain; charset=utf-8\n";

    mail($emailDocelowy, $subject, $body, $header);

    echo "[haslo_wyslane]";
}


function FormularzPrzypomnieniaHasla()
{
    return '
        <h2>Przypomnienie hasła</h2>
        <form method="POST" action="contact.php?task=przypomnij">
            
            <label>Podaj swój email:</label><br>
            <input type="email" name="email" required><br><br>

            <input type="submit" value="Wyślij przypomnienie">
        </form>
    ';
}


$adminEmail = "admin@domena.pl";   
$adminPass  = "123";                    

if (isset($_GET['task'])) {

    switch ($_GET['task']) {

        case "sendmail":
            WyslijMailKontakt($adminEmail);
            break;

        case "przypomnij":
            PrzypomnijHaslo($adminEmail, $adminPass);
            break;
    }

} else {
    echo PokazKontakt();
    echo "<hr><br>";
    echo FormularzPrzypomnieniaHasla();
}
?>