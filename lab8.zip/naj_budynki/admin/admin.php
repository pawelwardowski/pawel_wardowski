<?php
session_start();
include("../cfg.php");


function FormularzLogowania() {
    return '
    <h2>Panel administracyjny – logowanie</h2>
    <form method="POST">
        <label>Login:</label><br>
        <input type="text" name="login"><br><br>

        <label>Hasło:</label><br>
        <input type="password" name="haslo"><br><br>

        <input type="submit" value="Zaloguj">
    </form>';
}


//login

if(!isset($_SESSION['logged'])) $_SESSION['logged'] = false;

if($_SESSION['logged'] === false) {

    if(isset($_POST['login']) && isset($_POST['haslo'])) {

        if($_POST['login'] == $login && $_POST['haslo'] == $pass) {
            $_SESSION['logged'] = true;
            header("Location: admin.php");
            exit;
        } else {
            echo "<p style='color:red;'>Błędny login lub hasło!</p>";
            echo FormularzLogowania();
            exit;
        }
    }

    echo FormularzLogowania();
    exit;
}


//logout

if(isset($_GET['logout'])) {
    session_destroy();
    header("Location: admin.php");
    exit;
}


//menu

echo '<h1>Panel administracyjny</h1>';
echo '
<a href="admin.php?task=list">Lista podstron</a> |
<a href="admin.php?task=add">Dodaj podstronę</a> |
<a href="admin.php?logout=1">Wyloguj</a>
<hr>
';


function ListaPodstron($link) {
    $sql = "SELECT * FROM page_list ORDER BY id ASC";
    $result = mysqli_query($link, $sql);

    echo "<h2>Lista podstron</h2>";

    echo "<table border='1' cellpadding='6'>
            <tr>
                <th>ID</th>
                <th>Tytuł</th>
                <th>Status</th>
                <th>Akcje</th>
            </tr>";

    while($row = mysqli_fetch_assoc($result)) {
        echo "<tr>
            <td>{$row['id']}</td>
            <td>{$row['page_title']}</td>
            <td>".($row['status'] ? "Aktywna" : "Nieaktywna")."</td>
            <td>
                <a href='admin.php?task=edit&id={$row['id']}'>Edytuj</a> |
                <a href='admin.php?task=delete&id={$row['id']}' onclick=\"return confirm('Usunąć podstronę?');\">Usuń</a>
            </td>
        </tr>";
    }

    echo "</table>";
}


function DodajNowaPodstrone($link) {

    if(isset($_POST['title']) && isset($_POST['content'])) {

        $title = mysqli_real_escape_string($link, $_POST['title']);
        $content = mysqli_real_escape_string($link, $_POST['content']);
        $active = isset($_POST['active']) ? 1 : 0;

        $sql = "INSERT INTO page_list (page_title, page_content, status)
                VALUES ('$title', '$content', '$active')";

        mysqli_query($link, $sql);

        echo "<p><b>Dodano podstronę</b></p>";
    }

    echo '
    <h2>Dodaj nową podstronę</h2>
    <form method="POST">
        Tytuł:<br>
        <input type="text" name="title"><br><br>

        Treść:<br>
        <textarea name="content" rows="10" cols="60"></textarea><br><br>

        Aktywna:
        <input type="checkbox" name="active"><br><br>

        <input type="submit" value="Dodaj">
    </form>
    ';
}


function EdytujPodstrone($link, $id) {

    if(isset($_POST['title'])) {

        $title = mysqli_real_escape_string($link, $_POST['title']);
        $content = mysqli_real_escape_string($link, $_POST['content']);
        $active = isset($_POST['active']) ? 1 : 0;

        $sql = "UPDATE page_list 
                SET page_title='$title', page_content='$content', status='$active'
                WHERE id=$id LIMIT 1";

        mysqli_query($link, $sql);

        echo "<p><b>Zapisano zmiany!</b></p>";
    }

    $sql = "SELECT * FROM page_list WHERE id=$id LIMIT 1";
    $result = mysqli_query($link, $sql);
    $row = mysqli_fetch_assoc($result);

    echo '
    <h2>Edytuj podstronę</h2>
    <form method="POST">
        Tytuł:<br>
        <input type="text" name="title" value="'.$row['page_title'].'"><br><br>

        Treść:<br>
        <textarea name="content" rows="10" cols="60">'.$row['page_content'].'</textarea><br><br>

        Aktywna:
        <input type="checkbox" name="active" '.($row['status'] ? "checked" : "").'><br><br>

        <input type="submit" value="Zapisz zmiany">
    </form>';
}



function UsunPodstrone($link, $id) {

    $sql = "DELETE FROM page_list WHERE id=$id LIMIT 1";
    mysqli_query($link, $sql);

    echo "<p><b>Usunięto podstronę</b></p>";
}


if(isset($_GET['task'])) {

    switch($_GET['task']) {

        case "list":
            ListaPodstron($link);
            break;

        case "add":
            DodajNowaPodstrone($link);
            break;

        case "edit":
            if(isset($_GET['id'])) EdytujPodstrone($link, $_GET['id']);
            break;

        case "delete":
            if(isset($_GET['id'])) UsunPodstrone($link, $_GET['id']);
            break;
			
		case "kontakt":
			echo PokazKontakt();
			break;

		case "sendmail":
			WyslijMailKontakt("mail@domena.pl"); 
			break;
			
		case "forgot":
			echo FormularzPrzypomnieniaHasla();
			break;

		case "przypomnij":
			PrzypomnijHaslo("mail@domena.pl", $pass);
			break;

    }
}

?>

