<?php
session_start();
 $nr_indeksu = '1234567';
 $nrGrupy = 'X';

 echo "Paweł Wardowski<br>";
 
 echo '====Zastosowanie metody include()==== <br />'; //br = \n
 include("menu.php");
 
 echo '====Zastosowanie metody require_once()==== <br>';
 require_once("stopka.php");
 echo '<br><br>';
 
 
 echo '====Zastosowanie warunków if, else, elseif, switch==== <br>';
 echo 'Instrukcja if<br>';
 $wiek = 18;
 
 if($wiek >= 18)
 {
	echo "Jesteś pełnoletni<br><br>";
}

echo 'Instrukcja if else<br><br>';

$liczba = 5;
if ($liczba > 10) {
    echo "Liczba jest większa niż 10.<br><br>";
} else {
    echo "Liczba jest mniejsza lub równa 10.<br><br>";
}

echo "Instrukcja elseif<br><br>";

$ocena = 4;

if ($ocena == 5) {
    echo "Ocena bardzo dobra!<br><br>";
} elseif ($ocena == 4) {
    echo "Ocena dobra!<br><br>";
} elseif ($ocena == 3) {
    echo "Ocena dostateczna!<br><br>";
} else {
    echo "Ocena niedostateczna!<br><br>";
}

echo "Instrukcja switch<br><br>";

$dzien = "poniedziałek";

switch ($dzien) {
    case "poniedziałek":
        echo "Dzisiaj jest poniedziałek.<br><br>";
        break;
    case "wtorek":
        echo "Dzisiaj jest wtorek.<br><br>";
        break;
    case "środa":
        echo "Dzisiaj jest środa.<br><br>";
        break;
    default:
        echo "Nieznany dzień tygodnia.<br><br>";
}
 
 echo "==== Zastosowanie pętli while, for ====<br><br>";
 
 $licznik = 1;

while ($licznik <= 5) {
    echo "To jest pętla numer: $licznik <br>";
    $licznik++;
}

echo "<br>";

for ($i = 1; $i <= 5; $i++) {
    echo "To jest iteracja numer: $i <br>";
}
 
 echo "<br>";
 
 echo "==== Zastosowanie typów zmiennych _GET, _POST, _SESSION ====<br><br>";
 
 echo "Zastosowanie _GET<br><br>";
// sprawdź, czy parametr "imie" istnieje w adresie
if (isset($_GET["imie"])) {
    echo "Moje imię to <br><br>" . $_GET["imie"];
} else {
    echo "Nie podano imienia w adresie URL.<br><br>";
}

echo "Zastosowanie _POST<br><br>";
?>
<form method="post" action="">
  Imię: <input type="text" name="imie_post"><br>
  Wiek: <input type="number" name="wiek_post"><br>
  <input type="submit" value="Wyślij dane POST">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $imie_post = $_POST["imie_post"] ?? "";
    $wiek_post = $_POST["wiek_post"] ?? "";

    if (!empty($imie_post) && !empty($wiek_post)) {
	    $_SESSION["imie"] = $imie_post;
        $_SESSION["wiek"] = $wiek_post;
        echo "<br>Odebrano metodą POST:<br>";
        echo "Imię: $imie_post <br>";
        echo "Wiek: $wiek_post <br>";
    } else {
        echo "<br>Uzupełnij wszystkie pola formularza.";
    }
}

echo "<br>Zastosowanie _SESSION<br><br>";

if (isset($_SESSION["imie"]) && isset($_SESSION["wiek"])) {
    echo "Dane zapamiętane w sesji:<br>";
    echo "Imię: " . $_SESSION["imie"] . "<br>";
    echo "Wiek: " . $_SESSION["wiek"] . "<br>";
} else {
    echo "Brak danych w sesji.";
}
?>