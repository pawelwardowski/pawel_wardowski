<?php
	include('cfg.php');
?>

<?php
error_reporting(E_ALL ^ E_NOTICE ^ E_WARNING);

/* warunki get*/
if ($_GET['idp'] == '') $strona = 'html/glowna.html';
if ($_GET['idp'] == 'burj_khalifa') $strona = 'html/burj_khalifa.html';
if ($_GET['idp'] == 'merdeka') $strona = 'html/merdeka.html';
if ($_GET['idp'] == 'shanghai_tower') $strona = 'html/shanghai_tower.html';
if ($_GET['idp'] == 'lotte_world') $strona = 'html/lotte_world.html';
if($_GET['idp'] == 'filmy') $strona = 'html/filmy.html';
if ($_GET['idp'] == 'kontakt') $strona = 'html/kontakt.html';


/*zabezpieczenie*/
if (!file_exists($strona)) $strona = 'html/glowna.html';
?>

<!DOCTYPE html>
<html lang="pl">
<head>
<meta charset="UTF-8">
<meta name="description" content="Największe budynki świata">
<title>Największe budynki świata</title>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<link rel="stylesheet" href="css/style.css">
<script src="js/kolorujtlo.js"></script>
<script src="js/timedate.js"></script>

</head>
<body onload="startclock()">

<table>
  <tr>
    <td colspan="2" class="menu">
      <a href="index.php">Strona główna</a>
      <a href="index.php?idp=burj_khalifa">Burj Khalifa</a>
      <a href="index.php?idp=merdeka">Merdeka 118</a>
      <a href="index.php?idp=shanghai_tower">Shanghai Tower</a>
      <a href="index.php?idp=lotte_world">Lotte World Tower</a>
	  <a href="index.php?idp=filmy">Filmy</a>
      <a href="index.php?idp=kontakt">Kontakt</a>

      <div class="czas">
        <div id="zegarek"></div>
        <div id="data"></div>
      </div>
    </td>
  </tr>

  <tr>
    <td colspan="2" class="content">

      <?php include($strona); ?>

    </td>
  </tr>
</table>

<?php
$nr_indeksu = '164457';
$nrGrupy = '2';
$ver = 'v1.6';
echo 'Autor: Paweł Wardowski '.$nr_indeksu.' grupa '.$nrGrupy.' wersja '.$ver.' <br><br>';
?>

<script>
$(document).ready(function() {
  $(".zoom-image").on({
    mouseover: function() {
      $(this).stop().animate({
        width: "+=50px"
      }, 400);
    },
    mouseout: function() {
      $(this).stop().animate({
        width: "-=50px"
      }, 400);
    }
  });
});
</script>

<script>
function przejdzDoKolejnejStrony() {
    const strony = [
        "glowna",
        "burj_khalifa",
        "merdeka",
        "shanghai_tower",
        "lotte_world",
        "kontakt"
    ];

    let params = new URLSearchParams(window.location.search);
    let obecna = params.get("idp") || "glowna";

    let index = strony.indexOf(obecna);
    let next = strony[(index + 1) % strony.length];

    window.location.href = "index.php?idp=" + next;
}

function przejdzDoPoprzedniejStrony() {
    const strony = [
        "glowna",
        "burj_khalifa",
        "merdeka",
        "shanghai_tower",
        "lotte_world",
        "kontakt"
    ];

    let params = new URLSearchParams(window.location.search);
    let obecna = params.get("idp") || "glowna";

    let index = strony.indexOf(obecna);
    let prev = strony[(index - 1 + strony.length) % strony.length];

    window.location.href = "index.php?idp=" + prev;
}

</script>

</body>
</html>
