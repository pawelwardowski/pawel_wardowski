<?php
/*************************************************
 * PLIK: menu.php
 * OPIS: Wyświetla główne menu nawigacyjne strony
 *************************************************/

// Rozpoczęcie listy nieuporządkowanej (HTML <ul>)
echo "<ul>";

// Element menu: Strona główna
echo "<li><a href='index.php'>Strona główna</a></li>";

// Element menu: Kontakt
echo "<li><a href='kontakt.php'>Kontakt</a></li>";

// Element menu: Galeria
echo "<li><a href='galeria.php'>Galeria</a></li>";

// Zakończenie listy nieuporządkowanej
echo "</ul>";
?>
