<?php
/****************************************
 * PLIK: showpage.php
 * OPIS: Obsługa wyświetlania treści
 *       podstron z bazy danych
 ****************************************/
 
 
 /**
 * Funkcja pobiera treść podstrony z bazy danych
 * na podstawie jej identyfikatora.
 *
 * @param mysqli $link - połączenie z bazą danych
 * @param int $id - ID podstrony
 * @return string - treść strony lub komunikat błędu
 */
 
function PokazPodstrone($id)
{
	/* Zabezpieczenie ID przed SQL Injection */
    $id = (int)$id;
	
	$id_clear = htmlspecialchars($id);
	
	/* Zapytanie SQL z ograniczeniem LIMIT */
	$query = "SELECT * FROM page_list WHERE id='$id_clear' LIMIT 1";
	$result = mysql_query($query);
	$row = mysql_fetch_array($result);
	
	/* Jeśli strona nie istnieje */
	if(empty($row['id']))
	{
		$web = '[nie_znaleziono_strony]';
		
	}
	else
	{
		$web = $row['page_content'];
	}
	
	return $web;
	
}

?>